"""
Fig. 12 – Epoch vs Loss  (Mask R-CNN)
=======================================
Line chart showing training loss vs validation loss across epochs
for the Mask R-CNN model.

Key observation from paper:
  "reduced loss of the validation data compared with the loss of
   the training dataset"
  Mask R-CNN accuracy = 0.94

Paper: Traffic Sign Recognition Using Deep Learning
       Chitkara University, Punjab, India
"""

import matplotlib.pyplot as plt
import numpy as np

# ── Data (digitised from Fig. 12 in the paper) ────────────────────────────────
epochs = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Training: starts at 1.5, sharp drop to 0.7 at epoch 2, then gentle oscillation
train_loss = [1.50, 1.10, 0.70, 0.73, 0.68, 0.60, 0.52, 0.49, 0.64, 0.58, 0.59]

# Validation: starts at 0.80, slight rise to 0.83, then drops and tracks closely
val_loss   = [0.80, 0.81, 0.83, 0.72, 0.61, 0.60, 0.62, 0.57, 0.60, 0.62, 0.62]

# ── Plot ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

ax.plot(epochs, train_loss, color="#1f77b4", linewidth=2.2,
        label="training",   zorder=3)
ax.plot(epochs, val_loss,   color="#ff7f0e", linewidth=2.2,
        label="validation", zorder=3)

# ── Formatting to match paper exactly ─────────────────────────────────────────
ax.set_title("epoch vs loss", fontsize=15, fontweight="normal", pad=12)
ax.set_xlabel("epoch", fontsize=13)
ax.set_ylabel("loss",  fontsize=13)

ax.set_xlim(-0.3, 10.3)
ax.set_ylim(0.4, 1.6)
ax.set_xticks(epochs)
ax.set_yticks([0.4, 0.6, 0.8, 1.0, 1.2, 1.4])

# Draw a box border (paper shows full box frame)
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_color("#888888")
ax.tick_params(axis="both", labelsize=11)
ax.yaxis.grid(False)
ax.xaxis.grid(False)

legend = ax.legend(fontsize=11, frameon=True, loc="upper right",
                   framealpha=0.9, edgecolor="#cccccc")

plt.tight_layout()
plt.savefig("Fig12_EpochLoss_MaskRCNN.png", dpi=150, bbox_inches="tight",
            facecolor="white")
print("✓ Saved: Fig12_EpochLoss_MaskRCNN.png")
plt.show()
