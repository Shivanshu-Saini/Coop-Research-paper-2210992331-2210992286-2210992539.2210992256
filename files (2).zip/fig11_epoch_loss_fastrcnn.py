"""
Fig. 11 – Epoch vs Loss  (Fast R-CNN)
======================================
Line chart showing training loss vs validation loss across epochs
for the Fast R-CNN baseline model.

Key observation from paper:
  "loss of the training set was more than the loss of the validation dataset"
  Fast R-CNN accuracy = 0.93

Paper: Traffic Sign Recognition Using Deep Learning
       Chitkara University, Punjab, India
"""

import matplotlib.pyplot as plt
import numpy as np

# ── Data (digitised from Fig. 11 in the paper) ────────────────────────────────
epochs = [0, 1, 2, 3, 4, 5, 6, 7, 8]

# Training loss: starts high (3.0), drops steeply then gradually flattens
train_loss = [3.00, 1.50, 1.02, 0.93, 0.85, 0.74, 0.63, 0.51, 0.42]

# Validation loss: starts at 1.0, drops fast to ~0.25 and stays flat
val_loss   = [1.00, 0.50, 0.26, 0.24, 0.22, 0.21, 0.21, 0.20, 0.19]

# ── Plot ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

ax.plot(epochs, train_loss, color="#1f77b4", linewidth=2.2,
        label="training",   zorder=3)
ax.plot(epochs, val_loss,   color="#ff7f0e", linewidth=2.2,
        label="validation", zorder=3)

# ── Formatting to match paper exactly ─────────────────────────────────────────
ax.set_title("epoch vs loss", fontsize=15, fontweight="normal", pad=12)
ax.set_xlabel("epoch", fontsize=13)
ax.set_ylabel("loss",  fontsize=13)

ax.set_xlim(-0.3, 8.3)
ax.set_ylim(0, 3.2)
ax.set_xticks(epochs)
ax.set_yticks([0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0])

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_color("#888888")
ax.spines["bottom"].set_color("#888888")
ax.tick_params(axis="both", labelsize=11)
ax.yaxis.grid(False)
ax.xaxis.grid(False)

legend = ax.legend(fontsize=11, frameon=True, loc="upper right",
                   framealpha=0.9, edgecolor="#cccccc")

plt.tight_layout()
plt.savefig("Fig11_EpochLoss_FastRCNN.png", dpi=150, bbox_inches="tight",
            facecolor="white")
print("✓ Saved: Fig11_EpochLoss_FastRCNN.png")
plt.show()
