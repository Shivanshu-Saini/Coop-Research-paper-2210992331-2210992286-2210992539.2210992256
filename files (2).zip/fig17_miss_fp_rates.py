"""
Fig. 17 – Miss Rates and False Positive Rates on Indian Traffic Sign Dataset
=============================================================================
Grouped bar chart comparing three models on two error metrics:
  • Miss rate (%)        – proportion of true signs not detected
  • False positive rate (%) – proportion of false detections

Models compared:
  FCN (Fast R-CNN)   →  Miss: 6.00%,  FP: 6.95%  (~7%)
  Mask R-CNN         →  Miss: 3.30%,  FP: 5.60%
  Mask R-CNN (ours)  →  Miss: 3.25%,  FP: 2.92%  (~3%)

Paper: Traffic Sign Recognition Using Deep Learning
       Chitkara University, Punjab, India
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# ── Data (from Table 2 / Fig. 17 in the paper) ────────────────────────────────
models      = ["FCN", "Mask R-CNN", "Mask R-CNN(ours)"]
miss_rates  = [6.00, 3.30, 3.25]        # Miss rate (%)
fp_rates    = [7.00, 5.60, 3.00]        # False positive rate (%)

# Colours exactly as in paper (blue / orange / grey)
colors = ["#4472C4", "#ED7D31", "#A5A5A5"]

# ── Bar layout ────────────────────────────────────────────────────────────────
x          = np.array([0.0, 1.0])       # two metric groups
bar_width  = 0.22
offsets    = [-bar_width, 0, bar_width] # three models side by side per group

# ── Plot ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(9, 6))
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

for i, (model, miss, fp, col, off) in enumerate(
        zip(models, miss_rates, fp_rates, colors, offsets)):
    ax.bar(x[0] + off, miss, width=bar_width, color=col,
           label=model, edgecolor="none", zorder=3)
    ax.bar(x[1] + off, fp,   width=bar_width, color=col,
           edgecolor="none", zorder=3)

# ── Horizontal grid lines (paper has thin grey horizontals) ───────────────────
ax.yaxis.grid(True, color="#dddddd", linewidth=0.8, zorder=0)
ax.set_axisbelow(True)

# ── Formatting ────────────────────────────────────────────────────────────────
ax.set_title("Error rates on our Custom Dataset",
             fontsize=14, fontweight="bold", pad=14)
ax.set_ylabel("", fontsize=0)           # paper has no y-axis label

ax.set_xticks(x)
ax.set_xticklabels(["Miss rate(%)", "False positive rate(%)"], fontsize=12)
ax.set_ylim(0, 8)
ax.set_yticks(range(0, 9))
ax.tick_params(axis="both", labelsize=11, length=0)

# Remove most spines, keep bottom
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_visible(False)
ax.spines["bottom"].set_color("#888888")

# ── Legend (bottom-centre, horizontal) ───────────────────────────────────────
patches = [mpatches.Patch(color=c, label=m)
           for c, m in zip(colors, models)]
ax.legend(handles=patches, fontsize=10, frameon=False,
          loc="lower center", bbox_to_anchor=(0.5, -0.14),
          ncol=3, handlelength=1.2, handleheight=1.0)

plt.tight_layout()
plt.savefig("Fig17_Miss_FalsePositive_Rates.png", dpi=150,
            bbox_inches="tight", facecolor="white")
print("✓ Saved: Fig17_Miss_FalsePositive_Rates.png")
plt.show()
