"""
Fig. 13 – Epoch vs Loss  (RMR-CNN – Proposed Model)
=====================================================
Line chart showing training loss vs validation loss across epochs
for the proposed Refined Mask R-CNN (RMR-CNN) model with data augmentation
and all parametric changes.

Key observation from paper:
  "As the number of iterations increases, loss value decreases, attended by
   concurrent increases in accuracy of identifying the traffic signs."
  RMR-CNN accuracy = 0.974

Paper: Traffic Sign Recognition Using Deep Learning
       Chitkara University, Punjab, India
"""

import matplotlib.pyplot as plt
import numpy as np

# ── Data (digitised from Fig. 13 in the paper) ────────────────────────────────
epochs = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Training: starts at 1.6, sharp drop to 0.75 at epoch 2, then converges ~0.58
train_loss = [1.60, 1.15, 0.75, 0.80, 0.65, 0.63, 0.60, 0.62, 0.57, 0.61, 0.58]

# Validation: starts at 0.83, drops to 0.63, oscillates tightly around 0.64
val_loss   = [0.83, 0.77, 0.63, 0.70, 0.62, 0.64, 0.69, 0.65, 0.61, 0.66, 0.62]

# ── Plot ──────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

ax.plot(epochs, train_loss, color="#1f77b4", linewidth=2.2,
        label="training",   zorder=3)
ax.plot(epochs, val_loss,   color="#ff7f0e", linewidth=2.2,
        label="validation", zorder=3)

# ── Formatting to match paper exactly ─────────────────────────────────────────
ax.set_title("epoch vs loss", fontsize=15, fontweight="normal", pad=12)
ax.set_xlabel("epoch", fontsize=13)
ax.set_ylabel("loss",  fontsize=13)

ax.set_xlim(-0.3, 10.3)
ax.set_ylim(0.5, 1.7)
ax.set_xticks(epochs)
ax.set_yticks([0.6, 0.8, 1.0, 1.2, 1.4, 1.6])

# Full box border (paper style)
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_color("#888888")
ax.tick_params(axis="both", labelsize=11)
ax.yaxis.grid(False)
ax.xaxis.grid(False)

legend = ax.legend(fontsize=11, frameon=True, loc="upper right",
                   framealpha=0.9, edgecolor="#cccccc")

plt.tight_layout()
plt.savefig("Fig13_EpochLoss_RMRCNN.png", dpi=150, bbox_inches="tight",
            facecolor="white")
print("✓ Saved: Fig13_EpochLoss_RMRCNN.png")
plt.show()
