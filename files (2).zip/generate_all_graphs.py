"""
generate_all_graphs.py
======================
Master script – runs all 5 graph files and saves every figure.
Run this single file to reproduce ALL output graphs from the paper:

  "Traffic Sign Recognition Using Deep Learning"
  Chitkara University, Punjab, India

Output files produced:
  ├── Fig9_Pixel_Count_Graphs.png
  ├── Fig11_EpochLoss_FastRCNN.png
  ├── Fig12_EpochLoss_MaskRCNN.png
  ├── Fig13_EpochLoss_RMRCNN.png
  └── Fig17_Miss_FalsePositive_Rates.png

Usage:
  python generate_all_graphs.py
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import os

OUTPUT_DIR = "output_graphs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

plt.rcParams.update({
    "font.family":     "DejaVu Sans",
    "axes.titlesize":  14,
    "axes.labelsize":  12,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 11,
    "figure.dpi":      100,
})


# ══════════════════════════════════════════════════════════════════════════════
# FIG 9 – Pixel Count of Colours (Partial vs Full Sunlight)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fig9():
    colors_x    = ["Red", "White", "Black"]
    bar_color   = "#4472C4"

    # (a) partial sunlight   (b) full sunlight
    pixel_partial = [2400, 2600, 2200]
    pixel_full    = [7500, 13200, 11000]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    fig.patch.set_facecolor("white")
    x = np.arange(len(colors_x))

    # ── (a) ──
    ax1.bar(x, pixel_partial, width=0.50, color=bar_color, edgecolor="none", zorder=3)
    ax1.set_title("Pixel count", fontweight="normal")
    ax1.set_xlabel("Colors")
    ax1.set_ylabel("Pixel count")
    ax1.set_xticks(x);  ax1.set_xticklabels(colors_x)
    ax1.set_ylim(0, 3000);  ax1.set_yticks([0, 1000, 2000, 3000])
    ax1.tick_params(length=0)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.spines["left"].set_color("#cccccc")
    ax1.set_facecolor("white")
    # annotation (cyan marker on White bar)
    ax1.plot([0.92, 1.08], [310, 310], color="cyan", lw=1.2)
    ax1.plot([0.92, 1.08], [290, 290], color="cyan", lw=1.2)
    ax1.plot([1.10, 1.30], [300, 300], color="cyan", lw=1.2)

    # ── (b) ──
    ax2.bar(x, pixel_full, width=0.50, color=bar_color, edgecolor="none", zorder=3)
    ax2.set_title("Pixel count", fontweight="normal")
    ax2.set_xlabel("Colors")
    ax2.set_ylabel("Pixel count")
    ax2.set_xticks(x);  ax2.set_xticklabels(colors_x)
    ax2.set_ylim(0, 15000);  ax2.set_yticks([0, 5000, 10000, 15000])
    ax2.tick_params(length=0)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)
    ax2.spines["left"].set_color("#cccccc")
    ax2.set_facecolor("white")
    # annotation (pink marker on White bar)
    ax2.plot([0.92, 1.08], [1700, 1700], color="hotpink", lw=1.2)
    ax2.plot([0.92, 1.08], [1500, 1500], color="hotpink", lw=1.2)
    ax2.plot([1.10, 1.30], [1600, 1600], color="hotpink", lw=1.2)

    plt.tight_layout(pad=2.5)
    path = os.path.join(OUTPUT_DIR, "Fig9_Pixel_Count_Graphs.png")
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"  ✓  {path}")
    plt.show()
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# FIG 11 – Epoch vs Loss  (Fast R-CNN)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fig11():
    epochs     = [0, 1, 2, 3, 4, 5, 6, 7, 8]
    train_loss = [3.00, 1.50, 1.02, 0.93, 0.85, 0.74, 0.63, 0.51, 0.42]
    val_loss   = [1.00, 0.50, 0.26, 0.24, 0.22, 0.21, 0.21, 0.20, 0.19]

    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor("white");  ax.set_facecolor("white")

    ax.plot(epochs, train_loss, color="#1f77b4", linewidth=2.2, label="training")
    ax.plot(epochs, val_loss,   color="#ff7f0e", linewidth=2.2, label="validation")

    ax.set_title("epoch vs loss", fontweight="normal", pad=12)
    ax.set_xlabel("epoch");  ax.set_ylabel("loss")
    ax.set_xlim(-0.3, 8.3);  ax.set_ylim(0, 3.2)
    ax.set_xticks(epochs)
    ax.set_yticks([0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0])
    ax.spines["top"].set_visible(False);  ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#888888");  ax.spines["bottom"].set_color("#888888")
    ax.tick_params(length=0)
    ax.legend(frameon=True, framealpha=0.9, edgecolor="#cccccc", loc="upper right")

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "Fig11_EpochLoss_FastRCNN.png")
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"  ✓  {path}")
    plt.show()
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# FIG 12 – Epoch vs Loss  (Mask R-CNN)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fig12():
    epochs     = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    train_loss = [1.50, 1.10, 0.70, 0.73, 0.68, 0.60, 0.52, 0.49, 0.64, 0.58, 0.59]
    val_loss   = [0.80, 0.81, 0.83, 0.72, 0.61, 0.60, 0.62, 0.57, 0.60, 0.62, 0.62]

    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor("white");  ax.set_facecolor("white")

    ax.plot(epochs, train_loss, color="#1f77b4", linewidth=2.2, label="training")
    ax.plot(epochs, val_loss,   color="#ff7f0e", linewidth=2.2, label="validation")

    ax.set_title("epoch vs loss", fontweight="normal", pad=12)
    ax.set_xlabel("epoch");  ax.set_ylabel("loss")
    ax.set_xlim(-0.3, 10.3);  ax.set_ylim(0.4, 1.6)
    ax.set_xticks(epochs)
    ax.set_yticks([0.4, 0.6, 0.8, 1.0, 1.2, 1.4])
    for spine in ax.spines.values():
        spine.set_visible(True);  spine.set_color("#888888")
    ax.tick_params(length=0)
    ax.legend(frameon=True, framealpha=0.9, edgecolor="#cccccc", loc="upper right")

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "Fig12_EpochLoss_MaskRCNN.png")
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"  ✓  {path}")
    plt.show()
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# FIG 13 – Epoch vs Loss  (RMR-CNN – Proposed Model)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fig13():
    epochs     = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    train_loss = [1.60, 1.15, 0.75, 0.80, 0.65, 0.63, 0.60, 0.62, 0.57, 0.61, 0.58]
    val_loss   = [0.83, 0.77, 0.63, 0.70, 0.62, 0.64, 0.69, 0.65, 0.61, 0.66, 0.62]

    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor("white");  ax.set_facecolor("white")

    ax.plot(epochs, train_loss, color="#1f77b4", linewidth=2.2, label="training")
    ax.plot(epochs, val_loss,   color="#ff7f0e", linewidth=2.2, label="validation")

    ax.set_title("epoch vs loss", fontweight="normal", pad=12)
    ax.set_xlabel("epoch");  ax.set_ylabel("loss")
    ax.set_xlim(-0.3, 10.3);  ax.set_ylim(0.5, 1.7)
    ax.set_xticks(epochs)
    ax.set_yticks([0.6, 0.8, 1.0, 1.2, 1.4, 1.6])
    for spine in ax.spines.values():
        spine.set_visible(True);  spine.set_color("#888888")
    ax.tick_params(length=0)
    ax.legend(frameon=True, framealpha=0.9, edgecolor="#cccccc", loc="upper right")

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "Fig13_EpochLoss_RMRCNN.png")
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"  ✓  {path}")
    plt.show()
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# FIG 17 – Miss Rate & False Positive Rate (Model Comparison)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fig17():
    models     = ["FCN", "Mask R-CNN", "Mask R-CNN(ours)"]
    miss_rates = [6.00, 3.30, 3.25]
    fp_rates   = [7.00, 5.60, 3.00]
    bar_colors = ["#4472C4", "#ED7D31", "#A5A5A5"]

    x         = np.array([0.0, 1.0])
    bar_width  = 0.22
    offsets    = [-bar_width, 0.0, bar_width]

    fig, ax = plt.subplots(figsize=(9, 6))
    fig.patch.set_facecolor("white");  ax.set_facecolor("white")

    for model, miss, fp, col, off in zip(models, miss_rates, fp_rates,
                                         bar_colors, offsets):
        ax.bar(x[0] + off, miss, width=bar_width, color=col,
               label=model, edgecolor="none", zorder=3)
        ax.bar(x[1] + off, fp,   width=bar_width, color=col,
               edgecolor="none", zorder=3)

    ax.yaxis.grid(True, color="#dddddd", linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)

    ax.set_title("Error rates on our Custom Dataset",
                 fontweight="bold", pad=14)
    ax.set_xticks(x)
    ax.set_xticklabels(["Miss rate(%)", "False positive rate(%)"])
    ax.set_ylim(0, 8);  ax.set_yticks(range(0, 9))
    ax.tick_params(length=0)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color("#888888")

    patches = [mpatches.Patch(color=c, label=m)
               for c, m in zip(bar_colors, models)]
    ax.legend(handles=patches, frameon=False, loc="lower center",
              bbox_to_anchor=(0.5, -0.13), ncol=3,
              handlelength=1.2, handleheight=1.0)

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "Fig17_Miss_FalsePositive_Rates.png")
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"  ✓  {path}")
    plt.show()
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# BONUS – All three Epoch-vs-Loss graphs on one comparison figure
# ══════════════════════════════════════════════════════════════════════════════
def plot_combined_epoch_loss():
    """Side-by-side comparison of all three models' training curves."""
    fig, axes = plt.subplots(1, 3, figsize=(18, 5), sharey=False)
    fig.patch.set_facecolor("white")
    fig.suptitle("Epoch vs Loss – Model Comparison",
                 fontsize=15, fontweight="bold", y=1.02)

    datasets = [
        {
            "title":      "Fast R-CNN  (acc = 0.93)",
            "epochs":     [0, 1, 2, 3, 4, 5, 6, 7, 8],
            "train":      [3.00, 1.50, 1.02, 0.93, 0.85, 0.74, 0.63, 0.51, 0.42],
            "val":        [1.00, 0.50, 0.26, 0.24, 0.22, 0.21, 0.21, 0.20, 0.19],
            "ylim":       (0, 3.2),
            "yticks":     [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0],
        },
        {
            "title":      "Mask R-CNN  (acc = 0.94)",
            "epochs":     [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "train":      [1.50, 1.10, 0.70, 0.73, 0.68, 0.60, 0.52, 0.49, 0.64, 0.58, 0.59],
            "val":        [0.80, 0.81, 0.83, 0.72, 0.61, 0.60, 0.62, 0.57, 0.60, 0.62, 0.62],
            "ylim":       (0.4, 1.6),
            "yticks":     [0.4, 0.6, 0.8, 1.0, 1.2, 1.4],
        },
        {
            "title":      "RMR-CNN (ours)  (acc = 0.974)",
            "epochs":     [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "train":      [1.60, 1.15, 0.75, 0.80, 0.65, 0.63, 0.60, 0.62, 0.57, 0.61, 0.58],
            "val":        [0.83, 0.77, 0.63, 0.70, 0.62, 0.64, 0.69, 0.65, 0.61, 0.66, 0.62],
            "ylim":       (0.5, 1.7),
            "yticks":     [0.6, 0.8, 1.0, 1.2, 1.4, 1.6],
        },
    ]

    for ax, d in zip(axes, datasets):
        ax.set_facecolor("white")
        ax.plot(d["epochs"], d["train"], color="#1f77b4",
                linewidth=2.0, label="training")
        ax.plot(d["epochs"], d["val"],   color="#ff7f0e",
                linewidth=2.0, label="validation")
        ax.set_title(d["title"], fontsize=11, pad=8)
        ax.set_xlabel("epoch", fontsize=11)
        ax.set_ylabel("loss",  fontsize=11)
        ax.set_xlim(-0.5, max(d["epochs"]) + 0.5)
        ax.set_ylim(d["ylim"])
        ax.set_xticks(d["epochs"])
        ax.set_yticks(d["yticks"])
        ax.tick_params(length=0)
        for spine in ax.spines.values():
            spine.set_color("#aaaaaa")
        ax.legend(frameon=True, framealpha=0.9,
                  edgecolor="#cccccc", fontsize=9, loc="upper right")

    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "FigCombined_EpochLoss_AllModels.png")
    plt.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"  ✓  {path}")
    plt.show()
    plt.close()


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("\n═══ Generating all paper graphs ═══\n")

    print("[ Fig  9 ]  Pixel Count of Colours …")
    plot_fig9()

    print("[ Fig 11 ]  Epoch vs Loss – Fast R-CNN …")
    plot_fig11()

    print("[ Fig 12 ]  Epoch vs Loss – Mask R-CNN …")
    plot_fig12()

    print("[ Fig 13 ]  Epoch vs Loss – RMR-CNN …")
    plot_fig13()

    print("[ Fig 17 ]  Miss Rate & False Positive Rate …")
    plot_fig17()

    print("[ Bonus  ]  Combined Epoch vs Loss (all 3 models) …")
    plot_combined_epoch_loss()

    print(f"\n All graphs saved to → ./{OUTPUT_DIR}/\n")
