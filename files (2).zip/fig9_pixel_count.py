"""
Fig. 9 – Results of Pixel Count of Colours
============================================
Two side-by-side bar charts showing pixel counts of Red, White, and Black
colour channels for two lighting conditions:
  (a) Image partially exposed to sunlight  [Fig 8a]
  (b) Image fully exposed to sunlight      [Fig 8b]

Paper: Traffic Sign Recognition Using Deep Learning
       Chitkara University, Punjab, India
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# ── Data (read from Fig. 9 in the paper) ──────────────────────────────────────
colors      = ["Red", "White", "Black"]
bar_color   = "#4472C4"          # same steel-blue used in the paper's MATLAB plots

# (a) Partial sunlight – Fig 8(a)
pixel_partial = [2400, 2600, 2200]

# (b) Full sunlight – Fig 8(b)
pixel_full    = [7500, 13200, 11000]

# ── Plot ──────────────────────────────────────────────────────────────────────
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
fig.patch.set_facecolor("white")

x = np.arange(len(colors))
bar_width = 0.50

# ── subplot (a) ───────────────────────────────────────────────────────────────
bars1 = ax1.bar(x, pixel_partial, width=bar_width, color=bar_color,
                edgecolor="none", zorder=3)

ax1.set_title("Pixel count", fontsize=14, fontweight="normal", pad=10)
ax1.set_xlabel("Colors", fontsize=12)
ax1.set_ylabel("Pixel count", fontsize=12)
ax1.set_xticks(x)
ax1.set_xticklabels(colors, fontsize=11)
ax1.set_ylim(0, 3000)
ax1.set_yticks([0, 1000, 2000, 3000])
ax1.tick_params(axis="both", which="both", length=0)
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)
ax1.spines["left"].set_color("#cccccc")
ax1.spines["bottom"].set_color("#444444")
ax1.yaxis.grid(False)
ax1.set_facecolor("white")

# annotation marker (cyan lines visible in paper around White bar)
ax1.annotate("", xy=(1, 300), xytext=(1.3, 300),
             arrowprops=dict(arrowstyle="-", color="cyan", lw=1.5))
ax1.plot([0.95, 1.05], [310, 310], color="cyan", lw=1.2)
ax1.plot([0.95, 1.05], [290, 290], color="cyan", lw=1.2)

# ── subplot (b) ───────────────────────────────────────────────────────────────
bars2 = ax2.bar(x, pixel_full, width=bar_width, color=bar_color,
                edgecolor="none", zorder=3)

ax2.set_title("Pixel count", fontsize=14, fontweight="normal", pad=10)
ax2.set_xlabel("Colors", fontsize=12)
ax2.set_ylabel("Pixel count", fontsize=12)
ax2.set_xticks(x)
ax2.set_xticklabels(colors, fontsize=11)
ax2.set_ylim(0, 15000)
ax2.set_yticks([0, 5000, 10000, 15000])
ax2.tick_params(axis="both", which="both", length=0)
ax2.spines["top"].set_visible(False)
ax2.spines["right"].set_visible(False)
ax2.spines["left"].set_color("#cccccc")
ax2.spines["bottom"].set_color("#444444")
ax2.yaxis.grid(False)
ax2.set_facecolor("white")

# annotation marker (pink/magenta lines visible in paper around White bar)
ax2.annotate("", xy=(1, 1600), xytext=(1.3, 1600),
             arrowprops=dict(arrowstyle="-", color="hotpink", lw=1.5))
ax2.plot([0.95, 1.05], [1700, 1700], color="hotpink", lw=1.2)
ax2.plot([0.95, 1.05], [1500, 1500], color="hotpink", lw=1.2)

plt.tight_layout(pad=2.5)
plt.savefig("Fig9_Pixel_Count_Graphs.png", dpi=150, bbox_inches="tight",
            facecolor="white")
print("✓ Saved: Fig9_Pixel_Count_Graphs.png")
plt.show()
