# Traffic Sign Recognition Using Refined Mask R-CNN (RMR-CNN)

Based on the research paper by Sanya Bansal, Vishesh, Shivanshu Saini, Sharad Jindal  
**Chitkara University, Punjab, India**

---

## Overview

This project implements the **RMR-CNN** model for detecting and recognising
Indian road traffic signs under real-world conditions (light variation,
scale variation, occlusion, orientation change).

| Model       | Precision | Recall  | F-measure |
|-------------|-----------|---------|-----------|
| Fast R-CNN  | 93.05%    | 94.00%  | 93.40%    |
| Mask R-CNN  | 94.40%    | 96.70%  | 95.53%    |
| **RMR-CNN** | **97.08%**| **96.75%** | **96.87%** |

---

## Project Structure

```
traffic_sign_recognition/
├── rmr_cnn.py          # Main implementation
├── requirements.txt    # Dependencies
└── README.md

data/
├── indian_traffic_signs/   # Image files
├── annotations.json        # COCO-style annotations
└── templates/              # Template images per class (for histogram matching)
    ├── speed_30/
    ├── speed_40/
    └── ...

checkpoints/
└── rmr_cnn.pth             # Saved model weights
```

---

## Architecture

### Pre-processing Pipeline (3 stages)
1. **Shape Detection** – Finds circles, triangles, rectangles via contour analysis
2. **ROI Extraction** – Hough Circles for circular signs; edge detection for polygons
3. **Colour Probability** – Filters by red/white/black pixel thresholds (12/15/9%)

### RMR-CNN Improvements over Mask R-CNN
- **Even ROI Distribution** – Equal ROI count per object (prevents bias toward large objects)
- **Adjusted Weights** – RPN weight = 0.05, classifier weight = 0.20
- **Feature Pyramid Network** – ResNet-50 backbone retains low-resolution features
- **Data Augmentation** – 8 techniques: rotation, flip, brightness, zoom, shift×4

### Recognition (2-stage)
- **OCR (EasyOCR)** – For signs containing text/numbers
- **Histogram Matching** – For symbol-only signs (threshold: 82%)

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Train
python rmr_cnn.py --mode train

# Evaluate
python rmr_cnn.py --mode evaluate --model checkpoints/rmr_cnn.pth

# Inference on a single image
python rmr_cnn.py --mode infer --image path/to/image.jpg --model checkpoints/rmr_cnn.pth
```

---

## Dataset

Custom Indian Traffic Sign Dataset:
- **6,480 images** | **7,056 instances** | **87 categories**
- 70.12% high-resolution (up to 4128×2322 px)
- 80:20 train/test split → 5,664 train / 1,412 test images
- Categories: Mandatory, Cautionary, Informatory signs

---

## Hyperparameters

| Parameter          | Value  |
|--------------------|--------|
| Epochs             | 20     |
| Batch size         | 100    |
| Min image dim      | 32×32  |
| Max image dim      | 2048px |
| RPN weight         | 0.05   |
| Classifier weight  | 0.20   |
| Histogram threshold| 0.82   |

---

## References

- He et al. (2017) – Mask R-CNN (ICCV 2017)
- Girshick (2015) – Fast R-CNN (ICCV 2015)
- Lin et al. (2017) – Feature Pyramid Networks
