"""
Traffic Sign Recognition Using Refined Mask R-CNN (RMR-CNN)
============================================================
Based on: "Traffic Sign Recognition Using Deep Learning"
Authors: Sanya Bansal, Vishesh, Shivanshu Saini, Sharad Jindal
         Chitkara University, Punjab, India

Model: Refined Mask R-CNN (RMR-CNN)
Dataset: Custom Indian Traffic Signs – 6480 images, 87 categories
Achieved: Precision 97.08%, Recall 96.75%
"""

import os
import cv2
import numpy as np
import torch
import torch.nn as nn
import torchvision
from torchvision.models.detection import maskrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.models.detection.mask_rcnn import MaskRCNNPredictor
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
from PIL import Image
import easyocr
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from sklearn.metrics import precision_score, recall_score, f1_score
import json
import random
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1: CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

class Config:
    """Hyperparameters as described in Section V of the paper."""

    # Dataset
    NUM_CLASSES       = 88           # 87 Indian traffic sign categories + background
    MIN_IMAGE_DIM     = 32           # Minimum bounding box size (32×32 pixels)
    MAX_IMAGE_DIM     = 2048         # Maximum image dimension
    TRAIN_RATIO       = 0.80         # 80:20 train/test split
    TOTAL_IMAGES      = 6480
    TOTAL_INSTANCES   = 7056

    # Training
    NUM_EPOCHS        = 20           # As described in the paper
    BATCH_SIZE        = 4            # GPU-friendly batch (paper uses 100 images/batch)
    LEARNING_RATE     = 0.005
    MOMENTUM          = 0.9
    WEIGHT_DECAY      = 0.0005

    # RPN Weights (Section IV – Parametric Changes)
    RPN_WEIGHT        = 0.05         # Smaller weight for background regions in RPN
    CLASS_WEIGHT      = 0.20         # Larger weight for foreground in classification

    # Color probability thresholds (Section IV – Colour Probability)
    RED_THRESHOLD     = 0.12         # 12% red pixels
    WHITE_THRESHOLD   = 0.15         # 15% white pixels
    BLACK_THRESHOLD   = 0.09         # 9% black pixels

    # Histogram matching threshold (Section V – Traffic Sign Recognition)
    HISTOGRAM_THRESHOLD = 0.82       # 82% match to classify as a known sign

    # Device
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Paths
    DATA_DIR          = "./data/indian_traffic_signs"
    ANNOTATIONS_FILE  = "./data/annotations.json"
    MODEL_SAVE_PATH   = "./checkpoints/rmr_cnn.pth"
    TEMPLATES_DIR     = "./data/templates"   # For histogram matching


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2: PRE-PROCESSING PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

class ShapeDetector:
    """
    Step 1 of pre-processing – Shape Detection.
    Finds circle, triangle, and rectangle shapes in an image (the three
    dominant shapes of Indian traffic signs) and returns cropped ROI images.
    """

    def __init__(self, area_threshold_low=500, area_threshold_high=500_000):
        self.area_low  = area_threshold_low
        self.area_high = area_threshold_high

    def detect(self, image: np.ndarray):
        """
        Detect shapes in the image using contour analysis (OpenCV).
        Returns a list of (shape_type, bounding_box, cropped_region) tuples.
        """
        gray     = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred  = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detected = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if not (self.area_low < area < self.area_high):
                continue

            peri     = cv2.arcLength(cnt, True)
            approx   = cv2.approxPolyDP(cnt, 0.04 * peri, True)
            x, y, w, h = cv2.boundingRect(approx)

            if len(approx) > 8:                        # Circle
                shape = "circle"
            elif len(approx) == 3:                     # Triangle
                shape = "triangle"
            elif 4 <= len(approx) <= 6:                # Rectangle / Octagon
                shape = "rectangle"
            else:
                continue

            crop = image[y:y+h, x:x+w]
            detected.append((shape, (x, y, w, h), crop))

        return detected

    def visualize(self, image: np.ndarray, detections):
        """Draw detection bounding boxes on the image."""
        vis = image.copy()
        colors = {"circle": (0, 255, 0), "triangle": (0, 0, 255), "rectangle": (255, 0, 0)}
        for shape, (x, y, w, h), _ in detections:
            cv2.rectangle(vis, (x, y), (x+w, y+h), colors.get(shape, (255, 255, 0)), 2)
            cv2.putText(vis, shape, (x, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                        colors.get(shape, (255, 255, 0)), 2)
        return vis


class ROIExtractor:
    """
    Step 2 of pre-processing – Region of Interest (ROI) Extraction.
    Uses Hough Circle for circles; contour & edge detection for triangles/rectangles.
    Applies a 5% threshold crop to retrieve clean ROI without loss.
    """

    def extract_circular_roi(self, image: np.ndarray):
        gray   = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (9, 9), 2)
        circles = cv2.HoughCircles(
            blurred, cv2.HOUGH_GRADIENT, dp=1, minDist=50,
            param1=100, param2=30, minRadius=20, maxRadius=300
        )
        rois = []
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for cx, cy, r in circles[0]:
                margin = int(r * 1.05)           # 5% padding
                x1     = max(0, cx - margin)
                y1     = max(0, cy - margin)
                x2     = min(image.shape[1], cx + margin)
                y2     = min(image.shape[0], cy + margin)
                rois.append(image[y1:y2, x1:x2])
        return rois

    def extract_polygon_roi(self, image: np.ndarray, shape_type: str):
        gray     = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges    = cv2.Canny(gray, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        rois = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < 500:
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            pad_x = int(w * 0.05)
            pad_y = int(h * 0.05)
            x1 = max(0, x - pad_x)
            y1 = max(0, y - pad_y)
            x2 = min(image.shape[1], x + w + pad_x)
            y2 = min(image.shape[0], y + h + pad_y)
            rois.append(image[y1:y2, x1:x2])
        return rois

    def extract(self, image: np.ndarray, shape_type: str):
        if shape_type == "circle":
            return self.extract_circular_roi(image)
        else:
            return self.extract_polygon_roi(image, shape_type)


class ColorProbabilityFilter:
    """
    Step 3 of pre-processing – Colour Probability.
    Calculates the percentage of red, white, and black pixels.
    Only images with enough of these colours are forwarded to the model.

    Thresholds (from paper): Red=12%, White=15%, Black=9%

    RGB ranges are calibrated for both partially and fully sunlit conditions.
    """

    # Sunlit RGB ranges (Fig 8a – partially exposed)
    RED_RANGE_PARTIAL   = ((200, 255), (70, 110),  (80, 110))
    WHITE_RANGE_PARTIAL = ((220, 255), (215, 255), (200, 255))
    BLACK_RANGE_PARTIAL = ((40, 80),   (30, 70),   (20, 65))

    # Fully exposed (Fig 8b – fully exposed to sun)
    RED_RANGE_FULL      = ((190, 255), (20, 50),   (30, 60))
    WHITE_RANGE_FULL    = ((200, 255), (200, 255), (200, 255))
    BLACK_RANGE_FULL    = ((25, 60),   (25, 60),   (40, 80))

    def _in_range(self, pixel, r_range, g_range, b_range):
        r, g, b = int(pixel[2]), int(pixel[1]), int(pixel[0])
        return (r_range[0] <= r <= r_range[1] and
                g_range[0] <= g <= g_range[1] and
                b_range[0] <= b <= b_range[1])

    def compute(self, image: np.ndarray):
        """
        Returns (red_pct, white_pct, black_pct) for the image.
        Uses both partial and full sunlight ranges and picks the wider match.
        """
        total = image.shape[0] * image.shape[1]
        if total == 0:
            return 0.0, 0.0, 0.0

        red_count = white_count = black_count = 0
        for y in range(image.shape[0]):
            for x in range(image.shape[1]):
                px = image[y, x]
                if (self._in_range(px, *self.RED_RANGE_PARTIAL) or
                        self._in_range(px, *self.RED_RANGE_FULL)):
                    red_count += 1
                if (self._in_range(px, *self.WHITE_RANGE_PARTIAL) or
                        self._in_range(px, *self.WHITE_RANGE_FULL)):
                    white_count += 1
                if (self._in_range(px, *self.BLACK_RANGE_PARTIAL) or
                        self._in_range(px, *self.BLACK_RANGE_FULL)):
                    black_count += 1

        return red_count / total, white_count / total, black_count / total

    def should_forward(self, image: np.ndarray, cfg: Config = None):
        """Returns True if the image passes the colour thresholds."""
        cfg    = cfg or Config()
        r, w, b = self.compute(image)
        return (r >= cfg.RED_THRESHOLD or
                w >= cfg.WHITE_THRESHOLD or
                b >= cfg.BLACK_THRESHOLD)

    def fast_compute(self, image: np.ndarray):
        """Vectorised (fast) version using NumPy – preferred for inference."""
        img = image.astype(np.int32)
        B, G, R = img[:, :, 0], img[:, :, 1], img[:, :, 2]
        total   = image.shape[0] * image.shape[1]

        red_mask   = ((R >= 190) & (G <= 110) & (B <= 110))
        white_mask = ((R >= 200) & (G >= 200) & (B >= 200))
        black_mask = ((R <= 80)  & (G <= 80)  & (B <= 80))

        return red_mask.sum() / total, white_mask.sum() / total, black_mask.sum() / total


class PreprocessingPipeline:
    """Chains ShapeDetector → ROIExtractor → ColorProbabilityFilter."""

    def __init__(self, config: Config = None):
        self.cfg    = config or Config()
        self.shape  = ShapeDetector()
        self.roi    = ROIExtractor()
        self.color  = ColorProbabilityFilter()

    def __call__(self, image: np.ndarray):
        """
        Returns a list of valid ROI crops that passed all three filters.
        """
        detections = self.shape.detect(image)
        valid_crops = []

        for shape_type, bbox, crop in detections:
            rois = self.roi.extract(image, shape_type)
            for roi in rois:
                if roi.size == 0:
                    continue
                if self.color.should_forward(roi, self.cfg):
                    valid_crops.append({
                        "shape": shape_type,
                        "bbox":  bbox,
                        "crop":  roi,
                    })

        return valid_crops


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3: DATA AUGMENTATION  (8 techniques from Section V)
# ─────────────────────────────────────────────────────────────────────────────

class DataAugmentor:
    """
    Implements all 8 data augmentation methods described in Section V.
    Each method is applied randomly during training.
    """

    def rotate(self, image: np.ndarray, angle: float = None):
        """Image Rotation – clockwise or anticlockwise."""
        if angle is None:
            angle = random.choice([-30, -15, 15, 30])
        h, w   = image.shape[:2]
        M      = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
        rotated = cv2.warpAffine(image, M, (w, h),
                                 borderMode=cv2.BORDER_REPLICATE)
        return rotated

    def horizontal_flip(self, image: np.ndarray):
        """Horizontal Flipping – flip on y-axis."""
        return cv2.flip(image, 1)

    def brightness_change(self, image: np.ndarray, delta: int = None):
        """Brightness Change – subtract a constant from all pixels."""
        if delta is None:
            delta = random.randint(20, 60)
        aug = np.clip(image.astype(np.int32) - delta, 0, 255).astype(np.uint8)
        return aug

    def zoom_in(self, image: np.ndarray, factor: float = 0.25):
        """Zoom In – extra 25%, simulating a cropped close-up view."""
        h, w   = image.shape[:2]
        margin = int(min(h, w) * factor / 2)
        crop   = image[margin:h-margin, margin:w-margin]
        zoomed = cv2.resize(crop, (w, h))
        return zoomed

    def right_shift(self, image: np.ndarray, shift: int = None):
        """Right Shift – move image pixels to the right."""
        if shift is None:
            shift = random.randint(10, 30)
        M   = np.float32([[1, 0, shift], [0, 1, 0]])
        shifted = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]),
                                 borderMode=cv2.BORDER_REPLICATE)
        return shifted

    def left_shift(self, image: np.ndarray, shift: int = None):
        """Left Shift – move image pixels to the left."""
        if shift is None:
            shift = random.randint(10, 30)
        M   = np.float32([[1, 0, -shift], [0, 1, 0]])
        shifted = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]),
                                 borderMode=cv2.BORDER_REPLICATE)
        return shifted

    def top_shift(self, image: np.ndarray, shift: int = None):
        """Top Shifting – move objects upward in the image."""
        if shift is None:
            shift = random.randint(10, 30)
        M   = np.float32([[1, 0, 0], [0, 1, -shift]])
        shifted = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]),
                                 borderMode=cv2.BORDER_REPLICATE)
        return shifted

    def bottom_shift(self, image: np.ndarray, shift: int = None):
        """Bottom Shifting – move objects downward in the image."""
        if shift is None:
            shift = random.randint(10, 30)
        M   = np.float32([[1, 0, 0], [0, 1, shift]])
        shifted = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]),
                                 borderMode=cv2.BORDER_REPLICATE)
        return shifted

    def apply_random(self, image: np.ndarray, num_augmentations: int = 2):
        """Apply a random selection of augmentation methods."""
        methods = [
            self.rotate, self.horizontal_flip, self.brightness_change,
            self.zoom_in, self.right_shift, self.left_shift,
            self.top_shift, self.bottom_shift
        ]
        selected = random.sample(methods, min(num_augmentations, len(methods)))
        aug_image = image.copy()
        for method in selected:
            aug_image = method(aug_image)
        return aug_image

    def augment_dataset(self, images: list, labels: list, multiplier: int = 3):
        """
        Expand the dataset by a given multiplier using random augmentations.
        Each original image produces `multiplier` additional augmented copies.
        """
        aug_images, aug_labels = [], []
        for img, label in zip(images, labels):
            aug_images.append(img)
            aug_labels.append(label)
            for _ in range(multiplier):
                aug_images.append(self.apply_random(img))
                aug_labels.append(label)
        return aug_images, aug_labels


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4: DATASET
# ─────────────────────────────────────────────────────────────────────────────

class IndianTrafficSignDataset(Dataset):
    """
    PyTorch Dataset for the custom Indian Traffic Sign dataset.

    Expected annotations.json format:
    [
      {
        "image_path": "path/to/img.jpg",
        "annotations": [
          {
            "category_id": 1,
            "bbox": [x, y, w, h],
            "segmentation": [[x1,y1,x2,y2,...]]
          }
        ]
      }
    ]
    """

    def __init__(self, annotations_file: str, data_dir: str,
                 transforms=None, augment: bool = False):
        with open(annotations_file, "r") as f:
            self.data = json.load(f)
        self.data_dir   = data_dir
        self.transforms = transforms
        self.augmentor  = DataAugmentor() if augment else None
        self.preprocessor = PreprocessingPipeline()

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        entry      = self.data[idx]
        img_path   = os.path.join(self.data_dir, entry["image_path"])
        image_bgr  = cv2.imread(img_path)
        image_rgb  = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

        # Optional augmentation
        if self.augmentor:
            image_rgb = self.augmentor.apply_random(image_rgb)

        image_tensor = T.ToTensor()(Image.fromarray(image_rgb))

        # Build target dict
        boxes, labels, masks = [], [], []
        for ann in entry["annotations"]:
            x, y, w, h = ann["bbox"]
            # Skip boxes smaller than 30×30 (as per paper)
            if w < 30 or h < 30:
                continue
            boxes.append([x, y, x + w, y + h])
            labels.append(ann["category_id"])

            # Create binary mask from segmentation polygon
            seg  = ann.get("segmentation", [[x, y, x+w, y, x+w, y+h, x, y+h]])
            mask = np.zeros((image_rgb.shape[0], image_rgb.shape[1]), dtype=np.uint8)
            pts  = np.array(seg[0], dtype=np.int32).reshape(-1, 2)
            cv2.fillPoly(mask, [pts], 1)
            masks.append(mask)

        target = {
            "boxes":   torch.as_tensor(boxes,  dtype=torch.float32),
            "labels":  torch.as_tensor(labels, dtype=torch.int64),
            "masks":   torch.as_tensor(np.array(masks), dtype=torch.uint8)
                       if masks else torch.zeros((0, *image_rgb.shape[:2]), dtype=torch.uint8),
        }
        return image_tensor, target


def build_dataloaders(cfg: Config):
    """Build train and validation DataLoaders with 80:20 split."""
    full_ds  = IndianTrafficSignDataset(
        cfg.ANNOTATIONS_FILE, cfg.DATA_DIR, augment=False
    )
    n        = len(full_ds)
    n_train  = int(n * cfg.TRAIN_RATIO)
    train_ds, val_ds = torch.utils.data.random_split(
        full_ds, [n_train, n - n_train]
    )

    # Re-enable augmentation only on training split
    train_ds.dataset.augmentor = DataAugmentor()

    train_loader = DataLoader(
        train_ds, batch_size=cfg.BATCH_SIZE, shuffle=True,
        collate_fn=lambda b: tuple(zip(*b))
    )
    val_loader = DataLoader(
        val_ds, batch_size=cfg.BATCH_SIZE, shuffle=False,
        collate_fn=lambda b: tuple(zip(*b))
    )
    return train_loader, val_loader


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5: RMR-CNN MODEL
# ─────────────────────────────────────────────────────────────────────────────

class RefinedMaskRCNN(nn.Module):
    """
    Refined Mask R-CNN (RMR-CNN) as proposed in the paper.

    Improvements over standard Mask R-CNN:
    1. Even distribution of ROI – same number of ROIs per object
    2. Changed weights – RPN=0.05, classification=0.20
    3. Feature Pyramid Network backbone (ResNet-50)
    4. Custom number of output classes for Indian traffic signs
    """

    def __init__(self, num_classes: int, rpn_weight: float = 0.05,
                 class_weight: float = 0.20):
        super().__init__()
        self.rpn_weight   = rpn_weight
        self.class_weight = class_weight

        # Load pretrained Mask R-CNN with FPN backbone (ResNet-50)
        self.model = maskrcnn_resnet50_fpn(pretrained=True)

        # Replace the box predictor head
        in_features_box = self.model.roi_heads.box_predictor.cls_score.in_features
        self.model.roi_heads.box_predictor = FastRCNNPredictor(
            in_features_box, num_classes
        )

        # Replace the mask predictor head
        in_features_mask = self.model.roi_heads.mask_predictor.conv5_mask.in_channels
        hidden_layer     = 256
        self.model.roi_heads.mask_predictor = MaskRCNNPredictor(
            in_features_mask, hidden_layer, num_classes
        )

        # Apply parametric weight changes (Section IV)
        self._apply_weight_scaling()

    def _apply_weight_scaling(self):
        """Scale RPN and classifier weights as per Section IV of the paper."""
        for name, param in self.model.rpn.named_parameters():
            if "weight" in name:
                param.data *= self.rpn_weight
        for name, param in self.model.roi_heads.box_predictor.named_parameters():
            if "weight" in name:
                param.data *= self.class_weight

    def forward(self, images, targets=None):
        return self.model(images, targets)

    def predict(self, images):
        """Inference only (no targets needed)."""
        self.eval()
        with torch.no_grad():
            return self.model(images)


class EvenROISampler:
    """
    Parametric Change: Even Distribution of ROI.

    Standard Mask R-CNN randomly selects ROIs, favouring large objects.
    This sampler enforces equal ROI count per detected object.
    Applied at the region proposal stage (RPN).
    """

    def __init__(self, rois_per_object: int = 32):
        self.rois_per_object = rois_per_object

    def sample(self, proposals: list, gt_boxes: torch.Tensor):
        """
        Assign equal number of proposals to each ground-truth box.
        Returns balanced proposals for foreground and background.
        """
        num_objects    = len(gt_boxes)
        fg_per_object  = self.rois_per_object
        total_fg       = num_objects * fg_per_object

        sampled = []
        for gt_box in gt_boxes:
            ious    = torchvision.ops.box_iou(
                torch.stack(proposals), gt_box.unsqueeze(0)
            ).squeeze(1)
            top_idx = ious.topk(min(fg_per_object, len(proposals))).indices
            sampled.extend([proposals[i] for i in top_idx.tolist()])

        return sampled


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6: TRAFFIC SIGN RECOGNITION (OCR + Histogram Matching)
# ─────────────────────────────────────────────────────────────────────────────

class OCRRecognizer:
    """
    Optical Character Recognition for traffic signs with textual characters.
    Uses EasyOCR (enhanced from 'easyocr' as mentioned in the paper).
    """

    def __init__(self, languages: list = None):
        self.reader = easyocr.Reader(languages or ["en", "hi"], gpu=False)

    def recognize(self, image: np.ndarray):
        """
        Extract text from a traffic sign crop.
        Returns detected text and confidence.
        """
        results = self.reader.readtext(image)
        texts   = [(res[1], res[2]) for res in results]   # (text, confidence)
        return texts

    def has_text(self, image: np.ndarray, confidence_threshold: float = 0.5):
        """Returns True if the image contains recognisable text."""
        results = self.recognize(image)
        return any(conf >= confidence_threshold for _, conf in results)


class HistogramMatcher:
    """
    Histogram Matching for traffic signs without textual characters (symbols only).
    Compares the histogram of a detected crop against a library of template images.
    Threshold from paper: 0.82 (82% match).
    """

    def __init__(self, templates_dir: str, threshold: float = 0.82):
        self.threshold  = threshold
        self.templates  = {}                  # {label: histogram}
        self._load_templates(templates_dir)

    def _compute_histogram(self, image: np.ndarray):
        """Compute normalised 3-channel histogram."""
        hist = []
        for ch in range(3):
            h = cv2.calcHist([image], [ch], None, [256], [0, 256])
            h = cv2.normalize(h, h).flatten()
            hist.append(h)
        return np.concatenate(hist)

    def _load_templates(self, templates_dir: str):
        """Load template images from disk (one folder per class label)."""
        tdir = Path(templates_dir)
        if not tdir.exists():
            return
        for label_dir in tdir.iterdir():
            if label_dir.is_dir():
                label = label_dir.name
                hists = []
                for img_path in label_dir.glob("*.jpg"):
                    img = cv2.imread(str(img_path))
                    if img is not None:
                        hists.append(self._compute_histogram(img))
                if hists:
                    self.templates[label] = np.mean(hists, axis=0)

    def match(self, image: np.ndarray):
        """
        Compare query image histogram against all templates.
        Returns (best_label, score) or (None, score) if below threshold.
        """
        if not self.templates:
            return None, 0.0

        query_hist  = self._compute_histogram(image)
        best_label  = None
        best_score  = 0.0

        for label, tmpl_hist in self.templates.items():
            score = cv2.compareHist(
                query_hist.astype(np.float32),
                tmpl_hist.astype(np.float32),
                cv2.HISTCMP_CORREL
            )
            if score > best_score:
                best_score = score
                best_label = label

        if best_score >= self.threshold:
            return best_label, best_score
        return None, best_score


class TrafficSignRecognizer:
    """
    Two-stage recognizer as described in the paper:
    1. If the masked image has characters → OCR
    2. Otherwise → Histogram Matching
    """

    def __init__(self, templates_dir: str, histogram_threshold: float = 0.82):
        self.ocr     = OCRRecognizer()
        self.matcher = HistogramMatcher(templates_dir, histogram_threshold)

    def recognize(self, cropped_sign: np.ndarray):
        """
        Returns a dict with:
          method   – 'ocr' or 'histogram'
          label    – recognised class label or text
          score    – confidence / match score
        """
        if self.ocr.has_text(cropped_sign):
            texts = self.ocr.recognize(cropped_sign)
            if texts:
                label, score = max(texts, key=lambda t: t[1])
                return {"method": "ocr", "label": label, "score": score}

        label, score = self.matcher.match(cropped_sign)
        return {"method": "histogram", "label": label, "score": score}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7: TRAINING
# ─────────────────────────────────────────────────────────────────────────────

class Trainer:
    """
    Training loop for RMR-CNN.
    Tracks epoch-wise loss for the Epoch vs Loss plots (Fig 13 in the paper).
    """

    def __init__(self, model: RefinedMaskRCNN, cfg: Config):
        self.model  = model.to(cfg.DEVICE)
        self.cfg    = cfg
        self.device = cfg.DEVICE

        params = [p for p in model.parameters() if p.requires_grad]
        self.optimizer = torch.optim.SGD(
            params,
            lr           = cfg.LEARNING_RATE,
            momentum     = cfg.MOMENTUM,
            weight_decay = cfg.WEIGHT_DECAY,
        )
        self.scheduler = torch.optim.lr_scheduler.StepLR(
            self.optimizer, step_size=5, gamma=0.1
        )
        self.train_losses = []
        self.val_losses   = []

    def train_epoch(self, loader):
        self.model.train()
        epoch_loss = 0.0
        for images, targets in loader:
            images  = [img.to(self.device) for img in images]
            targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]

            loss_dict = self.model(images, targets)
            losses    = sum(loss_dict.values())

            self.optimizer.zero_grad()
            losses.backward()
            self.optimizer.step()
            epoch_loss += losses.item()

        return epoch_loss / max(len(loader), 1)

    @torch.no_grad()
    def validate_epoch(self, loader):
        self.model.train()           # Mask R-CNN needs train mode to compute losses
        epoch_loss = 0.0
        for images, targets in loader:
            images  = [img.to(self.device) for img in images]
            targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
            loss_dict  = self.model(images, targets)
            losses     = sum(loss_dict.values())
            epoch_loss += losses.item()
        return epoch_loss / max(len(loader), 1)

    def fit(self, train_loader, val_loader):
        """Full training run for NUM_EPOCHS epochs."""
        print(f"Training on {self.device}")
        Path(os.path.dirname(self.cfg.MODEL_SAVE_PATH)).mkdir(parents=True, exist_ok=True)

        best_val = float("inf")
        for epoch in range(1, self.cfg.NUM_EPOCHS + 1):
            t_loss = self.train_epoch(train_loader)
            v_loss = self.validate_epoch(val_loader)
            self.scheduler.step()

            self.train_losses.append(t_loss)
            self.val_losses.append(v_loss)

            print(f"Epoch [{epoch:02d}/{self.cfg.NUM_EPOCHS}]  "
                  f"Train Loss: {t_loss:.4f}  Val Loss: {v_loss:.4f}")

            if v_loss < best_val:
                best_val = v_loss
                torch.save(self.model.state_dict(), self.cfg.MODEL_SAVE_PATH)
                print(f"  ✓ Model saved (val loss: {v_loss:.4f})")

        print("\nTraining complete.")
        self.plot_loss()

    def plot_loss(self):
        """Reproduce the Epoch vs Loss graph (Fig 11/12/13 in the paper)."""
        epochs = range(1, len(self.train_losses) + 1)
        plt.figure(figsize=(8, 5))
        plt.plot(epochs, self.train_losses, "b-o", label="Training Loss")
        plt.plot(epochs, self.val_losses,   "r-o", label="Validation Loss")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.title("Epoch vs Loss – RMR-CNN")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig("epoch_vs_loss.png", dpi=150)
        plt.show()
        print("Loss plot saved as epoch_vs_loss.png")


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8: EVALUATION
# ─────────────────────────────────────────────────────────────────────────────

class Evaluator:
    """
    Computes Precision, Recall, and F-measure for detection and recognition.
    Results should reproduce Table 2 & Table 3 from the paper.
    """

    def __init__(self, iou_threshold: float = 0.5):
        self.iou_threshold = iou_threshold

    def compute_iou(self, box_a: list, box_b: list):
        """Compute IoU between two [x1,y1,x2,y2] boxes."""
        xA = max(box_a[0], box_b[0])
        yA = max(box_a[1], box_b[1])
        xB = min(box_a[2], box_b[2])
        yB = min(box_a[3], box_b[3])

        inter_area = max(0, xB - xA) * max(0, yB - yA)
        area_a = (box_a[2] - box_a[0]) * (box_a[3] - box_a[1])
        area_b = (box_b[2] - box_b[0]) * (box_b[3] - box_b[1])
        union  = area_a + area_b - inter_area
        return inter_area / union if union > 0 else 0.0

    @torch.no_grad()
    def evaluate(self, model: RefinedMaskRCNN, data_loader, device):
        """
        Run full evaluation and return precision, recall, and F-measure.
        Also reports miss rate and false positive rate (Fig 17).
        """
        model.eval()
        all_tp = all_fp = all_fn = 0

        for images, targets in data_loader:
            images = [img.to(device) for img in images]
            preds  = model.predict(images)

            for pred, target in zip(preds, targets):
                pred_boxes = pred["boxes"].cpu().numpy().tolist()
                gt_boxes   = target["boxes"].numpy().tolist()

                matched_gt = set()
                for pb in pred_boxes:
                    best_iou = 0
                    best_idx = -1
                    for i, gb in enumerate(gt_boxes):
                        if i in matched_gt:
                            continue
                        iou = self.compute_iou(pb, gb)
                        if iou > best_iou:
                            best_iou = iou
                            best_idx = i

                    if best_iou >= self.iou_threshold and best_idx >= 0:
                        all_tp += 1
                        matched_gt.add(best_idx)
                    else:
                        all_fp += 1

                all_fn += len(gt_boxes) - len(matched_gt)

        precision   = all_tp / max(all_tp + all_fp, 1)
        recall      = all_tp / max(all_tp + all_fn, 1)
        f_measure   = (2 * precision * recall / max(precision + recall, 1e-9))
        miss_rate   = 1.0 - recall
        fp_rate     = all_fp / max(all_tp + all_fp, 1)

        print("\n" + "=" * 50)
        print("RMR-CNN Evaluation Results")
        print("=" * 50)
        print(f"Precision  : {precision * 100:.2f}%  (paper: 97.08%)")
        print(f"Recall     : {recall    * 100:.2f}%  (paper: 96.75%)")
        print(f"F-measure  : {f_measure * 100:.2f}%  (paper: 96.87%)")
        print(f"Miss Rate  : {miss_rate * 100:.2f}%  (paper: ~3.25%)")
        print(f"FP Rate    : {fp_rate   * 100:.2f}%  (paper: ~2.92%)")
        print("=" * 50)

        return {
            "precision":  precision,
            "recall":     recall,
            "f_measure":  f_measure,
            "miss_rate":  miss_rate,
            "fp_rate":    fp_rate,
        }

    def print_comparison_table(self):
        """Reproduce Table 3 from the paper."""
        print("\nTable 3 – Precision, Recall, F-measure for all three models")
        print("-" * 55)
        header = f"{'Metric':<15} {'Fast R-CNN':>12} {'Mask R-CNN':>12} {'RMR-CNN':>10}"
        print(header)
        print("-" * 55)
        rows = [
            ("Precision (%)", 93.00, 94.40, 97.08),
            ("Recall    (%)", 94.00, 96.70, 96.75),
            ("F-measure (%)", 93.40, 95.53, 96.87),
        ]
        for metric, fast, mask, rmr in rows:
            print(f"{metric:<15} {fast:>12.2f} {mask:>12.2f} {rmr:>10.2f}")
        print("-" * 55)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 9: INFERENCE PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

class InferencePipeline:
    """
    End-to-end inference pipeline combining:
    Pre-processing → RMR-CNN Detection → OCR/Histogram Recognition
    """

    def __init__(self, model_path: str, cfg: Config):
        self.cfg          = cfg
        self.device       = cfg.DEVICE
        self.preprocessor = PreprocessingPipeline(cfg)
        self.recognizer   = TrafficSignRecognizer(cfg.TEMPLATES_DIR,
                                                  cfg.HISTOGRAM_THRESHOLD)

        self.model = RefinedMaskRCNN(cfg.NUM_CLASSES)
        if os.path.exists(model_path):
            self.model.load_state_dict(
                torch.load(model_path, map_location=self.device)
            )
        self.model.to(self.device).eval()

    def run(self, image_path: str, score_threshold: float = 0.5):
        """
        Full pipeline:
          1. Load image
          2. Pre-process (shape, ROI, colour probability)
          3. Run RMR-CNN detection
          4. Recognise each detected sign
          5. Return annotated image + results
        """
        image_bgr = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

        # Step 1: Pre-processing
        valid_rois = self.preprocessor(image_bgr)

        # Step 2: Detection
        tensor = T.ToTensor()(Image.fromarray(image_rgb)).to(self.device)
        with torch.no_grad():
            predictions = self.model.predict([tensor])[0]

        # Step 3: Filter by score
        boxes   = predictions["boxes"].cpu().numpy()
        scores  = predictions["scores"].cpu().numpy()
        labels  = predictions["labels"].cpu().numpy()
        masks   = predictions["masks"].cpu().numpy()

        keep    = scores >= score_threshold
        boxes   = boxes[keep]
        scores  = scores[keep]
        labels  = labels[keep]
        masks   = masks[keep]

        results = []
        for i, (box, score, label) in enumerate(zip(boxes, scores, labels)):
            x1, y1, x2, y2 = map(int, box)
            crop = image_rgb[y1:y2, x1:x2]

            recognition = self.recognizer.recognize(crop)
            results.append({
                "box":         [x1, y1, x2, y2],
                "score":       float(score),
                "class_id":    int(label),
                "recognition": recognition,
            })

        # Visualise
        annotated = self._draw_results(image_rgb.copy(), results)
        return annotated, results

    def _draw_results(self, image: np.ndarray, results: list):
        """Draw bounding boxes and labels on the image."""
        for res in results:
            x1, y1, x2, y2 = res["box"]
            score   = res["score"]
            label   = res["recognition"]["label"] or f"class_{res['class_id']}"
            method  = res["recognition"]["method"]

            colour  = (0, 255, 0) if method == "histogram" else (255, 165, 0)
            cv2.rectangle(image, (x1, y1), (x2, y2), colour, 2)
            text = f"{label} ({score:.2f})"
            cv2.putText(image, text, (x1, y1 - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, colour, 2)
        return image


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 10: ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def build_model(cfg: Config = None):
    cfg   = cfg or Config()
    model = RefinedMaskRCNN(
        num_classes  = cfg.NUM_CLASSES,
        rpn_weight   = cfg.RPN_WEIGHT,
        class_weight = cfg.CLASS_WEIGHT,
    )
    return model


def train(cfg: Config = None):
    cfg             = cfg or Config()
    model           = build_model(cfg)
    train_loader, val_loader = build_dataloaders(cfg)
    trainer         = Trainer(model, cfg)
    trainer.fit(train_loader, val_loader)
    return model, trainer


def evaluate(model_path: str = None, cfg: Config = None):
    cfg        = cfg or Config()
    model_path = model_path or cfg.MODEL_SAVE_PATH
    model      = build_model(cfg)
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=cfg.DEVICE))

    _, val_loader = build_dataloaders(cfg)
    evaluator     = Evaluator()
    results       = evaluator.evaluate(model, val_loader, cfg.DEVICE)
    evaluator.print_comparison_table()
    return results


def infer(image_path: str, model_path: str = None, cfg: Config = None):
    cfg        = cfg or Config()
    model_path = model_path or cfg.MODEL_SAVE_PATH
    pipeline   = InferencePipeline(model_path, cfg)
    annotated, results = pipeline.run(image_path)

    print(f"\nDetected {len(results)} traffic sign(s):")
    for i, r in enumerate(results, 1):
        print(f"  [{i}] {r['recognition']['label']} "
              f"(score={r['score']:.2f}, method={r['recognition']['method']})")

    out_path = "output_detection.jpg"
    cv2.imwrite(out_path, cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR))
    print(f"Annotated image saved to {out_path}")
    return annotated, results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="RMR-CNN – Indian Traffic Sign Recognition")
    parser.add_argument("--mode",    choices=["train", "evaluate", "infer"], default="train")
    parser.add_argument("--image",   type=str, help="Path to image for inference")
    parser.add_argument("--model",   type=str, help="Path to saved model weights")
    args = parser.parse_args()

    cfg = Config()

    if args.mode == "train":
        train(cfg)
    elif args.mode == "evaluate":
        evaluate(args.model, cfg)
    elif args.mode == "infer":
        if not args.image:
            parser.error("--image is required for inference mode")
        infer(args.image, args.model, cfg)
